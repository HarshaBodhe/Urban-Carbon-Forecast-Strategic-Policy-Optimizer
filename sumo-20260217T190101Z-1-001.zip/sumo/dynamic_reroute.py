import traci
import sumolib
import csv

# === Configuration ===
SUMO_BINARY = "sumo-gui"   # Use "sumo-gui" for GUI, "sumo" for CLI
CONFIG_FILE = "grid.sumocfg"
THRESHOLD_SPEED = 5  # km/h threshold to consider congestion

# === Load the SUMO network dynamically ===
net = sumolib.net.readNet("grid.net.xml")
edges = [e.getID() for e in net.getEdges() if not e.getID().startswith(":")]

# Initialize stats storage for each edge
edge_stats = {edge: {"flow": 0, "speed_sum": 0, "occupancy_sum": 0, "steps": 0} for edge in edges}

# === Start SUMO simulation ===
traci.start([SUMO_BINARY, "-c", CONFIG_FILE])
print("🚀 SUMO simulation started...")

# === Helper function to reroute vehicles dynamically ===
def reroute_vehicle(vehicle_id):
    current_edge = traci.vehicle.getRoadID(vehicle_id)
    if current_edge.startswith(":"):  # Skip internal junction edges
        return

    outgoing_edges = net.getEdge(current_edge).getOutgoing()
    if not outgoing_edges:
        return

    # Choose the fastest outgoing edge
    best_edge = None
    best_speed = 0
    for edge in outgoing_edges:
        edge_id = edge.getID()
        mean_speed = traci.edge.getLastStepMeanSpeed(edge_id)
        if mean_speed > best_speed:
            best_speed = mean_speed
            best_edge = edge_id

    if best_edge:
        try:
            traci.vehicle.changeTarget(vehicle_id, best_edge)
            print(f"🚗 Vehicle {vehicle_id} rerouted → {best_edge} (avg speed: {best_speed:.2f} km/h)")
        except traci.TraCIException:
            pass

# === Simulation Loop ===
try:
    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()

        # Reroute congested vehicles
        for vehicle_id in traci.vehicle.getIDList():
            speed = traci.vehicle.getSpeed(vehicle_id)
            if speed < THRESHOLD_SPEED:
                reroute_vehicle(vehicle_id)

        # Collect stats for all edges
        for edge in edges:
            flow = traci.edge.getLastStepVehicleNumber(edge)
            speed = traci.edge.getLastStepMeanSpeed(edge)
            occupancy = traci.edge.getLastStepOccupancy(edge)

            edge_stats[edge]["flow"] += flow
            edge_stats[edge]["speed_sum"] += speed * flow
            edge_stats[edge]["occupancy_sum"] += occupancy
            edge_stats[edge]["steps"] += 1

except traci.exceptions.FatalTraCIError:
    print("✅ SUMO simulation ended normally.")

finally:
    # Get simulation end time BEFORE closing TraCI
    end_time = traci.simulation.getTime()  # returns seconds as float

    traci.close()
    print("🔚 TraCI connection closed successfully.")

    # Write CSV
    with open("after_optimization.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["begin", "end", "id", "flow", "occupancy", "speed", "nVeh"])

        for edge, data in edge_stats.items():
            total_flow = data["flow"]
            avg_speed = (data["speed_sum"] / total_flow) if total_flow > 0 else 0
            avg_occupancy = (data["occupancy_sum"] / data["steps"]) if data["steps"] > 0 else 0
            nVeh = total_flow
            writer.writerow([0, round(end_time, 2), edge, total_flow, round(avg_occupancy, 2), round(avg_speed, 2), nVeh])

    print("✅ Detector statistics saved to 'after_optimization.csv'")

